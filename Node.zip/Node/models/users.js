exports.create = function(fn, ln, email, pass, bd, telephone, country){
    this.firstname = fn;
    this.lastname = ln;
    this.email = email;
    this.password = pass;
    this.birthdate = bd;
    this.telephone = telephone;
    this.country = country;
}