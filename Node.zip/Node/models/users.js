// exports.create = function(fn, ln, email, pass, bd, telephone, country){
//     this.firstname = fn;
//     this.lastname = ln;
//     this.email = email;
//     this.password = pass;
//     this.birthdate = bd;
//     this.telephone = telephone;
//     this.country = country;
// }

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

var usersSchema = new Schema ({
    firstName: {type: String, required: true},
    lastName: {type: String,  required: true},
    email: {type: String,  required: true},
    password:{type: String, required: true},
    birthDate: {type: String},
    telephone: {type: Number},
    country: {type: String}
})

var User = mongoose.model("User", usersSchema);

module.exports = User;