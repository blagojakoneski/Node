const users = require("./models/users");
const express = require("express");
var app = express();
const myParser = require("body-parser");
const user = require("./models/users");
const product = require("./models/products");
app.use(myParser.urlencoded({extended: true}));
const session = require("express-session");
app.use(session({secret: 'paskupatastra'}));

var u1 = new users.create("admin", "admin", "admin@yahoo.com", "000000", "18.08.1989", "078-458-299", "Northern Macedonia");


app.post("/register", (req, res) => {
    var firstname = req.body.firstname;
    var lastname = req.body.lastname;
    var email = req.body.email;
    var pass = req.body.pass;
    var birthdate = req.body.birthdate;
    var telephone = req.body.telephone;
    var country = req.body.country;

    var newUser = new users.create(fn, ln, email, pass, bd, telephone, country)
});

app.post("/login", (req, res) => {
    var email = req.body.emailLogin;
    var pass = req.body.passLogin;

    //database checks

    req.session.user = email;
    
    //return response to FE
});

app.post("/addProduct", (req, res) => {
    if(req.session.email){
        var productName = req.body.productName;
        var productDescription = req.body.productDescription;
        var productType = req.body.productType
        var purchaseDate = req.body.purchaseDate;
        var price = req.body.price;
        var userEmail = req.session.email;

        var p = new products.create(productName, productDescription, productType, purchaseDate, price, userEmail)

        //send response to frontEnd
    }

    else {
        res.status(400).send("Access denied");
    }

})