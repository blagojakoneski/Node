const users = require("./models/users");
const express = require("express");
var app = express();
const db = require("./connection");
const User = require("./models/users.js")
const myParser = require("body-parser");
const Product = require("./models/products");
app.use(myParser.urlencoded({extended: true}));
const session = require("express-session");
app.use(session({secret: 'paskupatastra'}));

app.listen(3000);

// var u1 = new users.create("admin", "admin", "admin@yahoo.com", "000000", "18.08.1989", "078-458-299", "Northern Macedonia");


app.post("/register", (req, res, next) => {
    var firstname = req.body.firstname;
    var lastname = req.body.lastname;
    var email = req.body.email;
    var pass = req.body.pass;
    var birthdate = req.body.birthdate;
    var telephone = req.body.telephone;
    var country = req.body.country;

    let user = new User({
        firstName: firstname,
        lastName: lastname,
        email: email,
        password: pass,
        birthDate: birthdate,
        telephone: telephone,
        country: country
    });

    user.save(function(err){
        if(err) {
            return next(err);
        }
        else {
            res.send("User saved.")
        }
    });

});

app.get("/products", (req, res) => {
    Product.find({ email: req.query.email}, function(err, products){
        if(err) {
            return next(err)
        }

        res.send(products);
    })
})

app.post("/login", (req, res) => {
    var email = req.body.emailLogin;
    var pass = req.body.passLogin;

    //database checks

    req.session.user = email;
    
    //return response to FE
});

app.post("/addProduct", (req, res, next) => {
   // if(req.session.email){
        var productName = req.body.productName;
        var productDescription = req.body.productDescription;
        var productType = req.body.productType
        var purchaseDate = req.body.purchaseDate;
        var price = req.body.price;
        var userEmail = req.session.email;

        let product = new Product ({
            productName: productName,
            productDescription: productDescription,
            productType: productType,
            purchaseDate: purchaseDate,
            price: price,
            userId: userEmail
        });

        product.save(function(err){
            if(err) {
                return next(err);
            }
            else {
                res.send("Product saved.")
            }
        });

        // var p = new products.create(productName, productDescription, productType, purchaseDate, price, userEmail)

        //send response to frontEnd
    // }

    // else {
    //     res.status(400).send("Access denied");
    // }

});

// app.get("/", (req, res) => {
//     res.send("Hello");
// });



